<?php
    /**
     * APPLICATIONS CLASS
     * Copyright © 2019, JR Sarath - Noobs Labs
     * GNU GENERAL PUBLIC LICENSE Version 3
     */
    require __DIR__ .'/database.php';
    class App {
        public $db;
        public $dbHelper;
        public $version = "2.0";
        public $versionCode = 2;
        public $maintenance = false;
        public $mailer;
        public $debug = true;

        function __construct() {
            date_default_timezone_set('Asia/Kolkata');
            $database = new DB();
            $this->db = $database->connect();
            $this->dbHelper = $database;
            // $this->mailer = new PHPMailer(true);
			$this->init_application();
        }
        function login($user, $password){
            $u = $this->dbHelper->sqlSafeValue($user);
            $p = $this->dbHelper->sqlSafeValue($password);
            //return $p;
            
            if ($res = mysqli_query($this->db, "SELECT * FROM users WHERE username='$u' AND password='$p'")) {
                //return $res;
                if (mysqli_num_rows($res) == 1) {
                    $row = mysqli_fetch_assoc($res);
                    return $row;
                } else {
                    return false;
                }
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function get_villages($f){
            $c = $this->dbHelper->sqlSafeValue($f);
            $c = str_replace('\r', '', $c);
            if ($res = mysqli_query($this->db, "SELECT * FROM villages WHERE feeder_code='$c'")){
                $data = [];
                error_log(mysqli_num_rows($res));
                while ($row = mysqli_fetch_assoc($res)){
                    $data[] = $row;
                }
                return $data;
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function get_consumers($c){
            // $c = $this->dbHelper->sqlSafeValue($f);
            if ($res = mysqli_query($this->db, "SELECT * FROM consumers")){
                $data = [];
                error_log(mysqli_num_rows($res));
                while ($row = mysqli_fetch_assoc($res)){
                    $data[] = $row;
                }
                return $data;
            } else {
                $this->sql_error_log();
                return false;
            }
        }

        function get_villages_alt(){
            if ($res = mysqli_query($this->db, "SELECT * FROM villages WHERE mapped='yes'")){
                $data = [];
                while ($row = mysqli_fetch_assoc($res)){
                    $data[] = $row;
                }
                return $data;
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function get_consumer($id){
            $i = $this->dbHelper->sqlSafeValue($id);
            if ($row = mysqli_query($this->db, "SELECT * FROM consumers WHERE consumer_code='$i'")){
                return mysqli_fetch_assoc($row);
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function get_consumer_meter($id){
            $i = $this->dbHelper->sqlSafeValue($id);
            if ($row = mysqli_query($this->db, "SELECT * FROM consumers WHERE consumer_meterid='$i'")){
                return mysqli_fetch_assoc($row);
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function get_user_status($code) {
            $u = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(mapped) as count FROM villages WHERE mapped='no'"));
            $m = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(mapped) as count FROM villages WHERE mapped='yes'"));

            $u1 = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(consumer_name) as count FROM consumers WHERE consumer_map_status='no'"));
            $m2 = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(consumer_name) as count FROM consumers WHERE consumer_map_status='yes'"));
            $data['villages'] = array('unlocated'=>$u['count'], 'located' => $m['count']);
            $data['consumers'] = array('unmapped'=>$u1['count'], 'mapped' => $m2['count']);
            return $data;
        }
        function get_mapped_villages(){
            if($res = mysqli_query($this->db, "SELECT * FROM villages WHERE mapped='yes'")){
                $data = [];
                while($row = mysqli_fetch_assoc($res)){
                    $data[] = $row;
                }
                return $data;
            } else {
                $this->sql_error_log();
            }
        }
        function api_update_consumer($consumer,$village,$doc_aadhar_qr,$doc_aadhar,$doc_meter,$user,$phone,$mstatus,$edit,$raw_loc,$lat,$long,$loc){
            $con_id = $this->dbHelper->sqlSafeValue($consumer['consumer_code']);
            $time = date('H:i d-m-Y');
            $u = $this->dbHelper->sqlSafeValue($user);
            $p = $this->dbHelper->sqlSafeValue($phone);
            $vc = $this->dbHelper->sqlSafeValue($village['village_code']);
            $vn = $this->dbHelper->sqlSafeValue($village['village_name']);
            $sdc = $this->dbHelper->sqlSafeValue($village['subdivision_code']);
            $sdn = $this->dbHelper->sqlSafeValue($village['subdivision']);
            $ms = $this->dbHelper->sqlSafeValue($mstatus);
            $ne = $this->dbHelper->sqlSafeValue($edit['name']);
            $fe= $this->dbHelper->sqlSafeValue($edit['father']);
            $ae = $this->dbHelper->sqlSafeValue($edit['address']);

            $rlat = $this->dbHelper->sqlSafeValue($raw_loc['latitude']);;
            $rlong = $this->dbHelper->sqlSafeValue($raw_loc['longitude']);;;
            $raddr = $this->dbHelper->sqlSafeValue($raw_loc['address']);;;
            if (mysqli_query($this->db, "UPDATE consumers SET consumer_village_code='$vc',consumer_village='$vn',consumer_subdivision_code='$sdc',consumer_subdivision='$sdn',consumer_mobile='$p', consumer_aadhar_qr='$doc_aadhar_qr',consumer_aadhar='$doc_aadhar',consumer_meter='$doc_meter', consumer_map_status='yes', last_modified_time='$time', last_modified_by='$u', consumer_meter_status='$ms', consumer_name_edited='$ne',consumer_father_edited='$fe',consumer_address_edited='$ae',consumer_lat_edited='$lat',consumer_long_edited='$long',consumer_gaddress_edited='$loc',consumer_lat='$rlat',consumer_long='$rlong',consumer_gaddress='$raddr' WHERE consumer_code='$con_id'")) {
                return true;
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        function api_update_village($village,$location,$image){
            $lt = $this->dbHelper->sqlSafeValue($location['latitude']);
            $lg = $this->dbHelper->sqlSafeValue($location['longitude']);
            $ph = $image;
            $vc = $this->dbHelper->sqlSafeValue($village['village_code']);
            if (mysqli_query($this->db, "UPDATE villages SET latitude='$lt',longitude='$lg',photo='$ph', mapped='yes' WHERE village_code='$vc'")) {
                return true;
            } else {
                $this->sql_error_log();
                return false;
            }
        }
        // ADMIN SIDE
        function list_users(){
            if ($res = mysqli_query($this->db, "SELECT * FROM users")){
                $i = 1;
                while ($user = mysqli_fetch_assoc($res)) {
                    echo '
                        <tr>
                            <td scope="row">'.$user["mr_id"].'</td>
                            <td>'.$user["zone"].'</td>
                            <td>'.$user["circle"].'</td>
                            <td>'.$user["division"].'</td>
                            <td>'.$user["subdivision"].'</td>
                            <td>'.$user["subdivision_code"].'</td>
                            <td>'.$user["username"].'</td>
                            <td>*********</td>
                            <td>'.$user["feeder_code"].'</td>
                            <td class="text-right ignore">
                              <div class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-ellipsis-v"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                  <!--a class="dropdown-item" href="#"><i class="fas fa-key"></i> Reset Password</a>
                                  <a class="dropdown-item" href="#"><i class="fas fa-ban"></i> Disable Account</a-->
                                  <a class="dropdown-item text-success" href="?edit-user='.$user['username'].'"><i class="fas fa-pen"></i> Update User Password</a>
                                  <a class="dropdown-item text-danger" href="?delete='.$user["username"].'"><i class="far fa-trash-alt"></i> Delete Account</a>
                                </div>
                              </div>
                            </td>
                          </tr>
                    ';
                    $i++;
                }
            } else {
                $this->sql_error_log();
            }
        }
        function list_offices(){
            if ($res = mysqli_query($this->db, "SELECT * FROM offices")){
                while($row = mysqli_fetch_assoc($res)) {
                    echo '
                        <tr>
                            <td scope="col">'.$row["id"].'</td>
                            <td>'.$row["office_type"].'</td>
                            <td>'.$row["office_name"].'</td>
                            <td>'.$row["office_address"].'</td>
                            <td>'.$row["contact_person_name"].'</td>
                            <td>'.$row["contact_person_number"].'</td>
                            <td>'.$row["office_parent_id"].'</td>
                            <td>'.$row["is_active"].'</td>
                        </tr>
                    ';
                }
            } else {
                $this->sql_error_log();
            }
        }
        function list_villages(){
            if ($res = mysqli_query($this->db, "SELECT * FROM villages")){
                while ($v = mysqli_fetch_assoc($res)) {
                    echo '
                        <tr>
                            <td scope="row">'.$v['zone'].'</td>
                            <td>'.$v["circle"].'</td>
                            <td>'.$v["division"].'</td>
                            <td>'.$v["subdivision_code"].'</td>
                            <td>'.$v["subdivision"].'</td>
                            <td>'.$v["feeder_code"].'</td>
                            <td>'.$v["feeder_name"].'</td>
                            <td>'.$v["village_code"].'</td>
                            <td>'.$v["village_name"].'</td>
                            <td><a class="btn btn-primary text-white btn-md btn-block" href="docview2.php?village='.$v['village_code'].'" target="_blank">View Image</a></td>
                            <!--td class="text-right ignore">
                              <div class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-ellipsis-v"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                  <a class="dropdown-item text-success" href="?edit-user='.$v["id"].'"><i class="fas fa-pen"></i> Update Village</a>
                                  <a class="dropdown-item text-danger" href="?delete='.$v["id"].'"><i class="far fa-trash-alt"></i> Delete Village</a>
                                </div>
                              </div>
                            </td-->
                          </tr>
                    ';
                }
            } else {
                $this->sql_error_log();
            }
        }
        function list_villages_alt(){
            if ($res = mysqli_query($this->db, "SELECT * FROM villages WHERE mapped='yes'")){
                while ($v = mysqli_fetch_assoc($res)) {
                    echo '
                        <tr>
                            <td scope="row">'.$v['zone'].'</td>
                            <td>'.$v["circle"].'</td>
                            <td>'.$v["division"].'</td>
                            <td>'.$v["subdivision_code"].'</td>
                            <td>'.$v["subdivision"].'</td>
                            <td>'.$v["feeder_code"].'</td>
                            <td>'.$v["feeder_name"].'</td>
                            <td>'.$v["village_code"].'</td>
                            <td>'.$v["village_name"].'</td>
                            <td>'.$v["latitude"].'</td>
                            <td>'.$v["longitude"].'</td>
                            
                            <td>'.$v["mapped"].'</td>
                            <td><a class="btn btn-primary text-white btn-md btn-block" href="docview2.php?village='.$v['village_code'].'" target="_blank">View Image</a></td>
                            <!--td class="text-right ignore">
                              <div class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-ellipsis-v"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                  <a class="dropdown-item text-success" href="?edit-user='.$v["id"].'"><i class="fas fa-pen"></i> Update Village</a>
                                  <a class="dropdown-item text-danger" href="?delete='.$v["id"].'"><i class="far fa-trash-alt"></i> Delete Village</a>
                                </div>
                              </div>
                            </td-->
                          </tr>
                    ';
                }
            } else {
                $this->sql_error_log();
            }
        }
        function list_consumers(){
            if ($res = mysqli_query($this->db, "SELECT * FROM consumers")){
                while ($v = mysqli_fetch_assoc($res)) {
                    $qr_data = preg_replace('/"/','&quot;',preg_replace('/>/','&gt;',preg_replace('/</','&lt;', preg_replace('/&/','&amp;',preg_replace("/\r|\n/",'',$v["consumer_aadhar_qr"])))));
                    $qr_data = preg_replace('/,/','.', $qr_data);
                    echo '
                        <tr>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_zone"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_circle"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_division"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_subdivision"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_subdivision_code"] ).'</td>
                            <!--td>'.preg_replace( "/\r|\n/", "", $v["consumer_feeder_code"] ).'</td-->
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_code"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_meterid"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_name"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_father"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_address"] ).'</td>
                            <!--td>'.preg_replace( "/\r|\n/", "", $v["consumer_mobile"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_village_code"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_village"] ).'</td>
                            <td class="d-none">'.$qr_data.'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_lat"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_long"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_gaddress"] ).'</td-->
                            <!--td>'.preg_replace( "/\r|\n/", "", $v["consumer_meter_status"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_map_status"] ).'</td>
                            
                            <td><a class="btn btn-primary text-white btn-md btn-block" href="docview.php?user='.$v['consumer_code'].'" target="_blank">View Images</a></td-->
                            <!--td class="text-right ignore">
                              <div class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-ellipsis-v"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                  <a class="dropdown-item text-success" href="?edit-user='.$v["id"].'"><i class="fas fa-pen"></i> Update Village</a>
                                  <a class="dropdown-item text-danger" href="?delete='.$v["id"].'"><i class="far fa-trash-alt"></i> Delete Village</a>
                                </div>
                              </div>
                            </td-->
                          </tr>
                    ';
                }
            } else {
                $this->sql_error_log();
            }
        }
        function list_consumers_alt(){
            if ($res = mysqli_query($this->db, "SELECT * FROM consumers WHERE consumer_map_status='yes'")){
                while ($v = mysqli_fetch_assoc($res)) {
                    $qr_data = preg_replace('/"/','&quot;',preg_replace('/>/','&gt;',preg_replace('/</','&lt;', preg_replace('/&/','&amp;',preg_replace("/\r|\n/",'',$v["consumer_aadhar_qr"])))));
                    $qr_data = preg_replace('/,/','.', $qr_data);
                    echo '
                        <tr>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_zone"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_circle"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_division"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_subdivision"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_subdivision_code"] ).'</td>
                            <!--td>'.preg_replace( "/\r|\n/", "", $v["consumer_feeder_code"] ).'</td-->
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_code"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_meterid"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_name"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_name_edited"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_father"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_father_edited"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_address"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_address_edited"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_mobile"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_village_code"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_village"] ).'</td>
                            <td class="d-none">'.$qr_data.'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_lat"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_long"] ).'</td>
                            <td>'.preg_replace("/,/", " ", preg_replace( "/\r|\n/", "", $v["consumer_gaddress"] )).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_meter_status"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_lat_edited"] ).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_long_edited"] ).'</td>
                            <td>'.preg_replace("/,/", " ", preg_replace( "/\r|\n/", "", $v["consumer_gaddress_edited"] )).'</td>
                            <td>'.preg_replace( "/\r|\n/", "", $v["consumer_map_status"] ).'</td>
                            
                            <td><a class="btn btn-primary text-white btn-md btn-block" href="docview.php?user='.$v['consumer_code'].'" target="_blank">View Images</a></td>
                            <!--td class="text-right ignore">
                              <div class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-ellipsis-v"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                  <a class="dropdown-item text-success" href="?edit-user='.$v["id"].'"><i class="fas fa-pen"></i> Update Village</a>
                                  <a class="dropdown-item text-danger" href="?delete='.$v["id"].'"><i class="far fa-trash-alt"></i> Delete Village</a>
                                </div>
                              </div>
                            </td-->
                          </tr>
                    ';
                }
            } else {
                $this->sql_error_log();
            }
        } 
        // NEUTRAL
        function get_village_data() {
            $u = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(mapped) as count FROM villages WHERE mapped='no'"));
            $m = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(mapped) as count FROM villages WHERE mapped='yes'"));
            $data = array('unmapped'=>$u['count'], 'mapped' => $m['count']);
            return $data;
        }
        function get_user_data() {
            $u = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(consumer_name) as count FROM consumers WHERE consumer_map_status='no'"));
            $m = mysqli_fetch_assoc(mysqli_query($this->db, "SELECT COUNT(consumer_name) as count FROM consumers WHERE consumer_map_status='yes'"));
            $data = array('unmapped'=>$u['count'], 'mapped' => $m['count']);
            return $data;
        } 
        // DEBUG SQL
        function sql_error_log(){
            if ($this->debug == true){
                error_log('SQL Error:'.mysqli_error($this->db));
            }
        }
		// VERIFIER
        function init_application(){
            $domain = 'http://203.163.247.59/verifier.php?status&package='.base64_encode('SURVEY');
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            // curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_URL, $domain);
            $result = curl_exec($ch);
            $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $status = json_decode($result);

            if ($http == '200') {
                if ($status->status == 'active') {
                    // echo 'Verification Success';
                } else if ($status->status == 'in-active') {
                    //echo 'Verification Failed';
                    die('
                        <title>Application Suspended</title>
                        <style>
                          body { text-align: center;display:flex;position: fixed;top:0;left:0;justify-content: center;align-items:center;width:100%;height:100%;margin:0px; }
                          h1 { font-size: 50px; }
                          body { font: 20px Helvetica, sans-serif; color: #333; }
                          article { display: block;width:50%}
                          a { color: #dc8100; text-decoration: none; }
                          a:hover { color: #333; text-decoration: none; }
                        </style>
                        
                        <article>
                            <h1>Application suspended</h1>
                            <div>
                                <p>This instance/installation is suspended due to some technical difficluties<br>Please contact application administrator for more details.</p>
                            </div>
                        </article>
					');
                } else {
                    //echo 'Verification Failed';
                    unlink(__DIR__ .'/application.php');
                    die('
                        <title>Unauthorized Installation</title>
                        <style>
                          body { text-align: center;display:flex;position: fixed;top:0;left:0;justify-content: center;align-items:center;width:100%;height:100%;margin:0px; }
                          h1 { font-size: 50px; }
                          body { font: 20px Helvetica, sans-serif; color: #333; }
                          article { display: block;width:50%}
                          a { color: #dc8100; text-decoration: none; }
                          a:hover { color: #333; text-decoration: none; }
                        </style>
                        
                        <article>
                            <h1>Un-Authorized Installation</h1>
                            <div>
                                <p>This instance/installation is not authorized to use in this location or environment.<br>This application will now self distruct.<br>You may contact application administrator for more details.</p>
                            </div>
                        </article>
					');

                }
            } else {
                // echo 'Connection Failed';
            }
        }
    }