<?php
  /**
  * DATABASE HELPER
  * AIRDROP - A COMPLETE PUBGM TOURNAMENT MANAGEMENT SOLUTION
  * Copyright © 2019, JR Sarath - Noobs Labs
  * GNU GENERAL PUBLIC LICENSE Version 3
  */
  class DB {
    function sqlSafePost($post) {
      return mysqli_real_escape_string($this->connect(), $_POST[$post]);
    }
    function sqlSafeValue($value) {
      return mysqli_real_escape_string($this->connect(), $value);
    }
    function connect() {
      $db_host = "localhost";
      // $db_name = "ais";
      // $db_user = "ais";
      $db_name = "ais";
      $db_user = "ais";
      $db_pass = "L5rs3ZKjU59Fqyw";
      //$db = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

      if (!$db = mysqli_connect($db_host, $db_user, $db_pass, $db_name)){
        error_log('SQL Error :'.mysqli_connect_error());
        die('Database connection failure');
      } else {
        return $db;
      }
    }
    function debug(){
      return $this->debug;
    }
  }
