<?php
/**
 * MAIN API ENDPOINT V1.0
 * Copyright © 2019, JR Sarath - Noobs Labs
 * GNU GENERAL PUBLIC LICENSE Version 3
 */
// CONFIG
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
$app = new App();
$apiKey = md5('KiONq##C36TL');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!empty($data['key']) && !empty($data['action'])){
        // VERIFY HASH
        if ($apiKey == $data['key']) {
            switch ($data['action']) {
                case 'login':
                    $res = $app->login($data['user'], md5($data['password']));
                    if ($res == true){
                        $res['status'] = 'success';
                        echo json_encode($res);
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'get_villages':
                    $res = $app->get_villages($data['feeder_code']);
                    echo json_encode($res);
                    /*if ($res == true){
                        echo json_encode($res);
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }*/
                    break;
                case 'get_villages_alt':
                    $res = $app->get_villages_alt();
                    if ($res == true){
                        echo json_encode($res);
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'get_consumers':
                    $res = $app->get_consumers(null);
                    echo json_encode($res);
                    break;
                case 'get_consumer':
                    $res = $app->get_consumer($data['consumer']);
                    if ($res == true){
                        $res['status'] = 'success';
                        echo json_encode($res);
                    } elseif (is_null($res)){
                        echo json_encode(array('status'=>'null'));
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'get_consumer_meterid':
                    $res = $app->get_consumer_meter($data['consumer']);
                    if ($res == true){
                        $res['status'] = 'success';
                        echo json_encode($res);
                    } elseif (is_null($res)){
                        echo json_encode(array('status'=>'null'));
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'update_consumer':
                    $res = $app->api_update_consumer($data["consumer"],$data["village"],$data["doc_aadhar_qr"],$data["doc_aadhar"],$data["doc_meter"], $data['user'],$data["mobile"],$data["mstatus"],$data["edit"],$data["raw_location"], $data["latitude"],$data["longitude"],$data["location"]);
                    if ($res == true){
                        echo json_encode(array('status'=>'success'));
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'update_village':
                    $res = $app->api_update_village($data['village'],$data['location'],$data['image']);
                    if ($res == true){
                        echo json_encode(array('status'=>'success'));
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'get_user_stat':
                    $res = $app->get_user_status($data['village_code']);
                    if ($res == true){
                        $res['status'] = 'success';
                        echo json_encode($res);
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                case 'get_mapped_villages':
                    $res = $app->get_mapped_villages();
                    if ($res == true){
                        echo json_encode($res);
                    } else {
                        echo json_encode(array('status'=>'false'));
                    }
                    break;
                default:
                    header('HTTP/1.0 403 Forbidden');
            }
        } else {
            header('HTTP/1.0 403 Forbidden');
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
    }
} else {
    header('HTTP/1.0 403 Forbidden');
}
?>