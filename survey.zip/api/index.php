<?php
    // SILENCE IS GOLDEN