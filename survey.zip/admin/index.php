<?php
    session_start();
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';

    if (!isset($_SESSION['admin_logged_in'])) {
        header('Location: /admin/login.php');
    }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="AIRDROP - A COMPLETE PUBGM TOURNAMENT MANAGEMENT SOLUTION">
    <meta name="author" content="Jr Sarath">
    <title>Login</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- Icons -->
    <link href="/admin/assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
    <link href="/admin/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!-- Argon CSS -->
    <link type="text/css" href="/admin/assets/css/argon.css?v=1.0.0" rel="stylesheet">
</head>

<body class="bg-default">
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary py-7 py-lg-8">
        <div class="container">
            <div class="header-body text-center mb-7">
                <div class="row justify-content-center">
                    <div class="col-lg-5 col-md-6">
                        <h1 class="text-white">Welcome, <? echo $_SESSION['admin_username']; ?>!</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="separator separator-bottom separator-skew zindex-100">
            <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
                <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
            </svg>
        </div>
    </div>
    <!-- Page content -->
    <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-9">
                <div class="card bg-secondary shadow border-0">
                    <div class="card-body p-6">
                        <div class="row">
                            <div class="col-6 text-center">
                                <a class="text-center" href="/admin/employees/">
                                    <img src="/admin/assets/img/employee.png" alt="" class="img-fluid" width="70%">
                                    <h1 class="text-center mt-5">Employees</h1>
                                </a>
                            </div>
                            <div class="col-6 text-center">
                                <a class="text-center" href="/admin/survey/">
                                    <img src="/admin/assets/img/village.png" alt="" class="img-fluid" width="70%">
                                    <h1 class="text-center mt-5">Consumer Survey</h1>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->

<!-- Argon Scripts -->
<!-- Core -->
<script src="/admin/assets/vendor/jquery/dist/jquery.min.js"></script>
<script src="/admin/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Argon JS -->
<script src="/admin/assets/js/argon.js?v=1.0.0"></script>
</body>

</html>
