<?php
    session_start();
    require_once $_SERVER['DOCUMENT_ROOT'].'/../application/classes/application.php';
    $app = new App();

    if (!isset($_SESSION['admin_logged_in'])) {
        header('Location: /login');
    }
    if ($_GET["type"] && $_GET["name"]) {
        // create var to be filled with export data
        $csv_export = '';
        $type = $_GET['type'];
        $csv_filename = $_GET["name"];
        // DEPRECATED FUNCTION OVERRIDE
        function mysqli_field_name($result, $field_offset){
            $properties = mysqli_fetch_field_direct($result, $field_offset);
            return is_object($properties) ? $properties->name : null;
        }
        // query to get data from database
        if ($type = 'consumers') {
            $query = mysqli_query($app->db,"SELECT * FROM consumers");
        }
        if ($type = 'consumers-updated') {
            $query = mysqli_query($app->db,"SELECT * FROM consumers WHERE consumer_map_status='yes'");
        }

        if ($type = 'villages'){
            $query = mysqli_query($app->db,"SELECT * FROM villages");
        }

        if ($type = 'villages-updated'){
            $query = mysqli_query($app->db,"SELECT * FROM villages WHERE mapped='yes'");
        }

        $field = mysqli_num_fields($query);

        // create line with field names
        for($i = 0; $i < $field; $i++) {
            $csv_export.= mysqli_field_name($query,$i).',';
        }
        // newline (seems to work both on Linux & Windows servers)
        $csv_export.= '
        ';

        while($row = mysqli_fetch_array($query)) {
            // create line with field values
            for($i = 0; $i < $field; $i++) {
                $csv_export.= '"'.$row[mysqli_field_name($query,$i)].'",';
            }
            $csv_export.= '
            ';
        }

        // Export the data and prompt a csv file for download
        header("Content-type: text/x-csv");
        header("Content-Disposition: attachment; filename=".$csv_filename."");
        echo($csv_export);
    }
?>