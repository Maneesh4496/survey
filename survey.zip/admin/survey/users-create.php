<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
$app = new App();
if (isset($_POST['submit'])){
    $u = $app->dbHelper->sqlSafePost('username');
    $p = md5($app->dbHelper->sqlSafePost("password"));
    $m = $app->dbHelper->sqlSafePost('mrid');
    $z = $app->dbHelper->sqlSafePost('zone');
    $c = $app->dbHelper->sqlSafePost('circle');
    $d = $app->dbHelper->sqlSafePost('division');
    $sd = $app->dbHelper->sqlSafePost('subdivision');
    $sdc = $app->dbHelper->sqlSafePost('subdivisioncode');
    $f = $app->dbHelper->sqlSafePost('feedercode');
    if (mysqli_query($app->db, "INSERT INTO users(username,password,mr_id,zone,circle,division,subdivision,subdivision_code,feeder_code) VALUES('$u','$p','$m','$z','$c','$d','$sd','$sdc','$f')")){
        $status = true;
    } else {
        $app->sql_error_log();
        $status = false;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>New User</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === true): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Created a new User
                        </div>
                    <?php elseif ($status === false): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to create User
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Add New User</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method='post' action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Username (Required)</label>
                                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Password (Required)</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>MR ID (Required)</label>
                                        <input type="text" name="mrid" class="form-control" placeholder="MR ID" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Zone (Required)</label>
                                        <input type="text" name="zone" class="form-control" placeholder="Zone" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Circle (Required)</label>
                                        <input type="text" name="circle" class="form-control" placeholder="Circle" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Division (Required)</label>
                                        <input type="text" name="division" class="form-control" placeholder="Division" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>SubDivision (Required)</label>
                                        <input type="text" name="subdivision" class="form-control" placeholder="SubDivision" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>SubDivision Code (Required)</label>
                                        <input type="text" name="subdivisioncode" class="form-control" placeholder="SubDivision Code" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Feeder Code (Required)</label>
                                        <input type="text" name="feedercode" class="form-control" placeholder="Feeder Code" required>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label></label>
                                        <input type="submit" name="submit" class="btn btn-success">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>