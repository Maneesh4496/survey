<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Updated Villages</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === "true"): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Villages imported successfully
                        </div>
                    <?php elseif ($status === "false"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to import villages
                        </div>
                    <?php elseif ($status === "invalid"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Please upload .csv files only
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">All Updated Villages</h3>
                            </div>
                            <div class="col">
                                <ul class="nav justify-content-end">
                                    <a onclick="table.button('.buttons-csv').trigger();" class="btn btn-primary py-2 px-3">
                                        <span>Export Excel</span>
                                    </a>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush" id='players'>
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Zone</th>
                                <th scope="col">Circle</th>
                                <th scope="col">Division</th>
                                <th scope="col">Subdivision P Code</th>
                                <th scope="col">Subdivison</th>
                                <th scope="col">Feeder A Code</th>
                                <th scope="col">Feeder Name</th>
                                <th scope="col">Village Code</th>
                                <th scope="col">Village Name</th>
                                <th scope="col">Latitude</th>
                                <th scope="col">Longitude</th>
                                <th scope="col">Mapped</th>
                                <th scope="col" class="ignore"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $app->list_villages_alt(null); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>
<script src="/assets/js/tableHTMLExport.js" charset="utf-8"></script>
</body>
</html>
