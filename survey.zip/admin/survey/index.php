<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Dashboard</title>
        <?php require('inc/templates/header.inc.php'); ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.css" integrity="sha256-aa0xaJgmK/X74WM224KMQeNQC2xYKwlAt08oZqjeF0E=" crossorigin="anonymous" />
        <style>
            /*th.sorting, th.sorting_asc, th.sorting_desc {
                white-space: normal;
            }
            .table-flush tbody tr:last-child td, .table-flush tbody tr:last-child th {
                white-space: normal;
            }*/
            .card .table td, .card .table th {
                /*padding-left: 0;
                padding-right: 0;*/
                text-align: center;
            }
        </style>
    </head>

    <body>
        <!-- Sidenav -->
        <?php require('inc/templates/sidenav.inc.php'); ?>
        <!-- Main content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
                <div class="container-fluid">
                    <div class="header-body">
                    </div>
                </div>
            </div>
            <!-- Page content -->
            <div class="container-fluid mt--7">
                <div class="row">
                    <div class="col-xl-12 mb-5 mb-xl-0">
                        <div class="card shadow">
                            <div class="card-header bg-transparent">
                                <div class="row align-items-center">
                                    <div class="col">
                                       <h3>Dashboard</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="table-responsive border border-primary mb-5">
                                            <table class="table align-items-center table-flush ">
                                                <thead class="thead-light">
                                                    <tr>
                                                        <th colspan="2">Villages</th>
                                                        <th colspan="2">Consumers</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th>Total</th>
                                                        <th><!-- <? echo +$app->get_village_data(false)['mapped'] + +$app->get_village_data(false)['unmapped'] ?> --> 7</th>
                                                        <th>Total</th>
                                                        <th><!-- <? echo +$app->get_user_data(false)['mapped'] + +$app->get_user_data(false)['unmapped'] ?> -->1002</th>
                                                    </tr>
                                                    <tr>
                                                        <th>Mapped</th>
                                                        <th><!-- <? echo $app->get_village_data(false)['mapped'] ?> -->1</th>
                                                        <th>Mapped</th>
                                                        <td><!-- <? echo $app->get_user_data(false)['mapped'] ?> -->3</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Unmapped</th>
                                                        <th><!-- <? echo $app->get_village_data(false)['unmapped'] ?> -->6</th>
                                                        <th>Unmapped</th>
                                                        <td><!-- <? echo $app->get_user_data(false)['unmapped'] ?> -->999</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="table-responsive border border-primary">
                                            <!-- Projects table -->
                                            <table class="table align-items-center table-flush " id='players' style="">
                                                <thead class="thead-light">
                                                <tr>
                                                    <th>Zone</th>
                                                    <th >Subdivision</th>
                                                    <!--th>Feeder Code</th-->
                                                    <th>Total Village Count</th>
                                                    <th >Mapped Village Count</th>
                                                    <th >Pending Count</th>
                                                    <th >Total Consumer Count</th>
                                                    <th >Mapped Count</th>
                                                    <th >Pending Count</th>
                                                    <th >No Mrs</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                    if($res = mysqli_query($app->db, "SELECT *, COUNT(*) as cont FROM villages GROUP BY zone, subdivision")) {
                                                        while ($row = mysqli_fetch_assoc($res)){
                                                            $mapped = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM villages WHERE mapped='yes' AND zone='".$row['zone']."' AND subdivision_code='".$row['subdivision_code']."'"));
                                                            $unmapped = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM villages WHERE mapped='no' AND zone='".$row['zone']."' AND subdivision_code='".$row['subdivision_code']."'"));

                                                            $consumers = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM consumers WHERE consumer_subdivision_code='".$row['subdivision_code']."'"));
                                                            $consumers_mapped = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM consumers WHERE consumer_map_status='yes' AND consumer_subdivision_code='".$row['subdivision_code']."'"));
                                                            $consumers_unmapped = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM consumers WHERE consumer_map_status='no' AND consumer_subdivision_code='".$row['subdivision_code']."'"));
                                                            $mrs = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT *,COUNT(*) AS cont FROM users WHERE subdivision_code='".$row['subdivision_code']."'"));
                                                            if ($row['zone'] !== '') {
                                                                echo '
                                                                    <tr>
                                                                        <td>'.$row['zone'].'</td>
                                                                        <td>'.$row['subdivision'].'</td>
                                                                        <!--td>'.$row['feeder_code'].'</td-->
                                                                        <td>'.$row['cont'].'</td>
                                                                        <td>'.$mapped['cont'].'</td>
                                                                        <td class="text-danger"><b>'.$unmapped['cont'].'</b></td>
                                                                        <td>'.$consumers['cont'].'</td>
                                                                        <td>'.$consumers_mapped['cont'].'</td>
                                                                        <td class="text-danger"><b>'.$consumers_unmapped['cont'].'</b></td>
                                                                        <td>'.$mrs['cont'].'</td>
                                                                    </tr>
                                                                ';
                                                            }
                                                        }
                                                    } else {
                                                        $app->sql_error_log();
                                                    }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--div class="col-12">
                                        <div class="col-6">
                                            <h4 class="my-4">Locate Village:</h4>
                                            <div class="ml-4">
                                                <h4>Located: <b class="text-danger"><? echo $app->get_village_data(false)['mapped'] ?></b></h4>
                                                <h4>Unlocated: <b class="text-danger"><? echo $app->get_village_data(false)['unmapped'] ?></b></h4>
                                            </div>
                                            <canvas id="villagesGraph"></canvas>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="col-6">
                                            <h4 class="my-4">Map Consumers:</h4>
                                            <div class="ml-4">
                                                <h4>Mapped: <b class="text-danger"><? echo $app->get_user_data(false)['mapped'] ?></b></h4>
                                                <h4>Unmapped: <b class="text-danger"><? echo $app->get_user_data(false)['unmapped'] ?></b></b></h4>
                                            </div>
                                            <canvas id="usersGraph"></canvas>
                                        </div>
                                    </div-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php require('inc/templates/footer.inc.php'); ?>
            </div>
        </div>
        <?php require('inc/templates/scripts.inc.php'); ?>
    </body>
</html>
