<?php
                $userinfo = array("admin@surveyprod.cf"=>"5F4DCC3B5AA765D61D8327DEB882CF99");
