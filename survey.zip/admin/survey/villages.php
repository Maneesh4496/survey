<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
    if (isset($_POST['import'])) {
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        $file = $_FILES["csv"];
        if ($file["size"] > 0 && in_array($file['type'], $csvMimes)) {
            if (is_uploaded_file($file['tmp_name'])){
                $f = $file["tmp_name"];
                $d = date('d-m-Y');
                $t = time();
                $file = file_get_contents($f);
                $lines = explode("\n", $file);
                $b = false;
                foreach ($lines as &$line) {
                    if(!$b) {       //edited for accuracy
                        $b = true;
                        continue;
                    }
                    $data = explode(",", $line);
                    if (mysqli_query($app->db, "INSERT INTO villages(district_code,district_name,subdistrict_code,subdistrict_name,village_name,village_code) VALUES('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')")) {
                        //SILENCE
                    } else {
                        error_log('SQL Error :'.mysqli_error($app->db));
                        $status = "false";
                    }
                }
                $status = 'true';
            } else {
                $status = "false";
            }
        } else {
            $status = 'invalid';
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Villages</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === "true"): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Villages imported successfully
                        </div>
                    <?php elseif ($status === "false"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to import villages
                        </div>
                    <?php elseif ($status === "invalid"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Please upload .csv files only
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Village Data</h3>
                            </div>
                            <div class="col">
                                <ul class="nav justify-content-end">
                                    <a onclick="table.button('.buttons-csv').trigger();" class="btn btn-primary py-2 px-3">
                                        <span>Export Excel</span>
                                    </a>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush" id='players'>
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Zone</th>
                                <th scope="col">Circle</th>
                                <th scope="col">Division</th>
                                <th scope="col">Subdivison P Code</th>
                                <th scope="col">Subdivision</th>
                                <th scope="col">Feeder A Code</th>
                                <th scope="col">Feeder Name</th>
                                <th scope="col">Village Code</th>
                                <th scope="col">Village Name</th>
                                <th scope="col" class="ignore"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $app->list_villages(null); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>
<script src="/assets/js/tableHTMLExport.js" charset="utf-8"></script>
</body>
</html>
