<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Updated Consumers</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === "true"): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Consumers imported successfully
                        </div>
                    <?php elseif ($status === "false"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to import Consumers
                        </div>
                    <?php elseif ($status === "invalid"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Please upload .csv files only
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">All Updated Consumers</h3>
                            </div>
                            <div class="col">
                                <ul class="nav justify-content-end">
                                    <a onclick="table.button('.buttons-csv').trigger();" class="btn btn-primary py-2 px-3">
                                        <span>Export Excel</span>
                                    </a>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush" id='players'>
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Zone</th>
                                <th scope="col">Circle</th>
                                <th scope="col">Division</th>
                                <th scope="col">SubDivision</th>
                                <th scope="col">SubDivision P Code</th>
                                <!--th scope="col">Feeder A Code</th-->
                                <th scope="col">Consumer Code</th>
                                <th scope="col">Meter ID</th>
                                <th scope="col">Consumer Name</th>
                                <th scope="col">Consumer Name Edited</th>
                                <th scope="col">Consumer Father's name</th>
                                <th scope="col">Consumer Father's name Edited</th>
                                <th scope="col">Consumer Address</th>
                                <th scope="col">Consumer Address Edited</th>
                                <th scope="col">Mobile No</th>
                                <th scope="col">Village Code</th>
                                <th scope="col">Village Name</th>
                                <th scope="col" class="d-none qrdata">Adhaar Data</th>
                                <th scope="col">Lat</th>
                                <th scope="col">Long</th>
                                <th scope="col">Address</th>
                                <th scope="col">Meter Status</th>
                                <th scope="col">Selected Lat</th>
                                <th scope="col">Selected Long</th>
                                <th scope="col">Selected Address</th>
                                <th scope="col">Map Status</th>
                                <th scope="col" class="ignore"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $app->list_consumers_alt(null); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
<script>

</script>
</body>
</html>
