<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
 $app = new App();
 if ($res = mysqli_query($app->db, "SELECT * FROM consumers WHERE consumer_code='".$_GET["user"]."'")){
   $row = mysqli_fetch_assoc($res);
 } else {
   error_log("MYSQLI ERROR: ".mysqli_error($app->db));
 }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Images for <?php echo $row['name'] ?></title>
  <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
  <!-- Sidenav -->
  <?php require('inc/templates/sidenav.inc.php'); ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
      <div class="row">
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
            <div class="card-header bg-transparent">
              <div class="row align-items-center">
                <div class="col">
                  <h3>Documents for : <?php echo $row['consumer_name'].' - '.$row['consumer_code'] ?></h3>
                  <h5 class="text-uppercase text-muted ls-1 mb-1">Last Modified : <?php echo $row['last_modified_time'] ?>, By : <?php echo $row['last_modified_by'] ?></h5>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-5">
                    <h2 class="mb-3">Image of Aadhar:</h2>
                    <img src="<?php echo $row['consumer_aadhar'] ?>" class='w-100 border rounded' alt="" id='aadhar'>
                    <a href="#" onclick="downloadImg('#aadhar')" class="btn btn-primary btn-block btn-lg mt-3" data-toggle="tab">
                        <span>Download Image</span>
                    </a>
                </div>
                <div class="col-md-4 mb-5">
                    <h2 class="mb-3">Image of Consumer Meter</h2>
                    <img src="<?php echo $row['consumer_meter'] ?>" class='w-100 border rounded' alt="" id='meter'>
                    <a href="#" onclick="downloadImg('#meter')" class="btn btn-primary btn-block btn-lg mt-3" data-toggle="tab">
                        <span>Download Image</span>
                    </a>
                </div>
                <div class="col-md-4 mb-5">
                    <h2 class="mb-3">Aadhar's QR Data</h2>
                    <textarea class="form-control w-100" style="min-height:200px" disabled>
                          <?php echo $row['consumer_aadhar_qr'] ?>
                      </textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php require('inc/templates/footer.inc.php'); ?>
    </div>
  </div>
  <?php require('inc/templates/scripts.inc.php'); ?>
  <script>
    function downloadImg(t){
      var img = $(t).attr('src');
      /*var url = img.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');
      window.open(url);
      console.log(url);*/
      download(img, Math.random().toString(36).substring(7)+".jpg", "image/jpg" );
    }
  </script>
</body>
</html>
