<?php
    session_start();
    require_once $_SERVER['DOCUMENT_ROOT'] . '/application/classes/application.php';

    $app = new App();
    if (isset($_POST['consumers'])){
        if (mysqli_query($app->db, "TRUNCATE TABLE consumers")) {
            $status = 'consumers-cleared';
        }
    }
    if (isset($_POST['villages'])){
        if (mysqli_query($app->db, "TRUNCATE TABLE villages")) {
            $status = 'villages-cleared';
        }
    }
  // alert
     if (!empty($status)){
                    if ($status == 'consumers-cleared'){
                        echo '<div class="alert alert-success" role="alert">
                                  <strong>Done!</strong> Consumers data cleared
                                </div>';
                    } elseif ($status == 'villages-cleared'){
                        echo '<div class="alert alert-success" role="alert">
                                  <strong>Done!</strong> Villages data cleared
                                </div>';
                    }
                }


?>
<!DOCTYPE html>
<html>
<head>
    <title>Flush Database</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <!-- <?
                if (!empty($status)){
                    if ($status == 'consumers-cleared'){
                        echo '<div class="alert alert-success" role="alert">
                                  <strong>Done!</strong> Consumers data cleared
                                </div>';
                    } elseif ($status == 'villages-cleared'){
                        echo '<div class="alert alert-success" role="alert">
                                  <strong>Done!</strong> Villages data cleared
                                </div>';
                    }
                }
                ?> -->
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3>Flush Database</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <form action="" method='post'>
                                    <div class="col-12 mb-5 mt-3">
                                        <input type="submit" class="btn btn-danger btn-block" name="consumers" value="Flush Consumers">
                                    </div>
                                </form>
                            </div>
                            <div class="col">
                                <form action="" method='post'>
                                    <div class="col-12 mb-5 mt-3">
                                        <input type="submit" class="btn btn-danger btn-block" name="villages" value="Flush Villages">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>
