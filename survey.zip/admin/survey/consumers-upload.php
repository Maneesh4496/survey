<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
    if (isset($_POST['import'])) {
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        $file = $_FILES["csv"];
        if ($file["size"] > 0 && in_array($file['type'], $csvMimes)) {
            if (is_uploaded_file($file['tmp_name'])){
                $f = $file["tmp_name"];
                $d = date('d-m-Y');
                $t = time();
                $file = file_get_contents($f);
                $lines = explode("\n", $file);
                $b = false;
                foreach ($lines as &$line) {
                    if(!$b) {       //edited for accuracy
                        $b = true;
                        continue;
                    }
                    $data = explode(",", $line);
                    //error_log($data[3]);
                    if (!empty($data[5])) {
                        if (mysqli_query($app->db, "INSERT INTO consumers(consumer_zone,consumer_circle,consumer_division,consumer_subdivision,consumer_subdivision_code,consumer_code,consumer_meterid,consumer_name,consumer_father,consumer_address) 
                                                                      VALUES('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]')")) {
                            //SILENCE
                        } else {
                            error_log('SQL Error :'.mysqli_error($app->db));
                            $status = "false";
                        }
                    }

                }
                $status = 'true';
            } else {
                $status = "false";
            }
        } else {
            $status = 'invalid';
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Consumers</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === "true"): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Consumers imported successfully
                        </div>
                    <?php elseif ($status === "false"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to import Consumers
                        </div>
                    <?php elseif ($status === "invalid"): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Please upload .csv files only
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header">

                        <div class="row align-items-center">
                            <div class="col">
                                <h3>Bulk Import consumers</h3>
                            </div>
                            <div class="col">
                                <a class="btn btn-primary float-right" href="consumers.csv" target="_blank">Download Sample file</a>
                            </div>
                        </div>

                    </div>
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">

                            <div class="form-group">
                                <label>Select <b>.CSV</b> file: *</label>
                                <input type="file" id="csv" name="csv" class="form-control form-control-alternative" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"  required/>
                            </div>
                            <input type="submit" name="import" class="btn btn-success btn-lg" value="Import Consumers" />
                            <p class="text-muted mt-4">**Importing a large csv file can take some time please be patient</p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>
