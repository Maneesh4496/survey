<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-gradient-default" id="sidenav-main">
  <div class="container-fluid">
    <!-- Toggler -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <!--a class="navbar-brand pt-0" href="/">
      <img src="./assets/img/logo.jpg" class="navbar-brand-img" alt="...">
    </a-->
    <!-- Collapse -->
    <div class="collapse navbar-collapse bg-gradient-default" id="sidenav-collapse-main">
      <!-- Collapse header -->
      <div class="navbar-collapse-header d-md-none">
        <div class="row">
          <div class="col-6 collapse-brand">
            <a href="./index.html">
              <!--img src="./assets/img/logo.jpg"-->
            </a>
          </div>
          <div class="col-6 collapse-close">
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
              <span></span>
              <span></span>
            </button>
          </div>
        </div>
      </div>
      <!-- Navigation -->
      <ul class="navbar-nav">
        <li class="nav-item nav-link">
          <a class="btn btn-success nav-link mb-2 text-left" href="/admin">
            <i class="fas fa-random"></i> Switch Sections
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-home "></i> Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"  data-toggle="collapse" data-target="#users">
            <i class="fas fa-user "></i> Users
          </a>
            <div class="collapse" id="users" aria-expanded="false">
                <ul style="list-style: none">
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-user "></i> User Master
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users-create.php">
                            <i class="fas fa-plus "></i> Create User
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users-upload.php">
                            <i class="fas fa-file-upload "></i> Users Bulk Upload
                        </a>
                    </li>
                </ul>
            </div>

        </li>
          <li class="nav-item">
              <a class="nav-link" href="#"  data-toggle="collapse" data-target="#villages">
                  <i class="fas fa-globe-asia "></i> Villages
              </a>
              <div class="collapse" id="villages" aria-expanded="false">
                  <ul style="list-style: none">
                      <li class="nav-item">
                          <a class="nav-link" href="villages.php">
                              <i class="fas fa-globe-asia "></i> Village Data
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="villages-updated.php">
                              <i class="fas fa-pencil-alt "></i> Reports
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="villages-upload.php">
                              <i class="fas fa-file-upload "></i> Village Upload
                          </a>
                      </li>
                  </ul>
              </div>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="#" data-toggle="collapse" data-target="#consumers">
                  <i class="fas fa-users "></i> Consumers
              </a>
              <div class="collapse" id="consumers" aria-expanded="false">
                  <ul style="list-style: none">
                      <li class="nav-item">
                          <a class="nav-link" href="consumers.php">
                              <i class="fas fa-users "></i> Consumer Data
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="consumers-updated.php">
                              <i class="fas fa-pencil-alt "></i> Reports
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="consumers-upload.php">
                              <i class="fas fa-file-upload "></i> Consumer Upload
                          </a>
                      </li>
                  </ul>
              </div>
          </li>
        <li class="nav-item">
          <a class="nav-link" href="change-login.php">
            <i class="fas fa-key "></i> Change Password
          </a>
        </li>
          <li class="nav-item">
              <a class="nav-link" href="flush-database.php">
                  <i class="fas fa-trash-alt"></i> Flush Database
              </a>
          </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="fas fa-power-off "></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
