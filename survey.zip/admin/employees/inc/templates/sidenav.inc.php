<?php
  //require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
  $krow = mysqli_fetch_assoc(mysqli_query($app->db, "SELECT COUNT(email) as cnt FROM users WHERE docverified='pending'"));
  $wrow = mysqli_fetch_assoc(mysqli_query($app->db,"SELECT COUNT(user) as cnt FROM withdraw WHERE status='PENDING'"));
?>

<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-gradient-default" id="sidenav-main">
  <div class="container-fluid">
    <!-- Toggler -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <!--a class="navbar-brand pt-0" href="/">
      <img src="./assets/img/logo.jpg" class="navbar-brand-img" alt="...">
    </a-->
    <!-- Collapse -->
    <div class="collapse navbar-collapse bg-gradient-default" id="sidenav-collapse-main">
      <!-- Collapse header -->
      <div class="navbar-collapse-header d-md-none">
        <div class="row">
          <div class="col-6 collapse-brand">
            <a href="./index.html">
              <!--img src="./assets/img/logo.jpg"-->
            </a>
          </div>
          <div class="col-6 collapse-close">
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
              <span></span>
              <span></span>
            </button>
          </div>
        </div>
      </div>
      <!-- Navigation -->
      <ul class="navbar-nav">
        <li class="nav-item nav-link">
          <a class="btn btn-success nav-link mb-2 text-left" href="/employees">
            <i class="fas fa-random"></i> Switch Sections
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-home "></i> Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"  data-toggle="collapse" data-target="#users">
            <i class="fas fa-building"></i> Offices
          </a>
            <div class="collapse" id="users" aria-expanded="false">
                <ul style="list-style: none">
                    <li class="nav-item">
                        <a class="nav-link" href="offices.php">
                            <i class="fas fa-building "></i> Office Master
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="office-create.php">
                            <i class="fas fa-plus "></i> Add Office
                        </a>
                    </li>
                    <!--li class="nav-item">
                        <a class="nav-link" href="office-upload.php">
                            <i class="fas fa-file-upload "></i> Office Bulk Upload
                        </a>
                    </li-->
                </ul>
            </div>

        </li>
          <li class="nav-item">
              <a class="nav-link" href="#" data-toggle="collapse" data-target="#consumers">
                  <i class="fas fa-users "></i> Employees
              </a>
              <div class="collapse" id="consumers" aria-expanded="false">
                  <ul style="list-style: none">
                      <li class="nav-item">
                          <a class="nav-link" href="employees.php">
                              <i class="fas fa-users "></i> Employee Master
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="employee-joining.php">
                              <i class="fas fa-plus "></i> Employee Joining
                          </a>
                      </li>
                  </ul>
              </div>
          </li>
        <li class="nav-item">
          <a class="nav-link" href="/change-login.php">
            <i class="fas fa-key "></i> Change Password
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/logout.php">
            <i class="fas fa-power-off "></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
