<!-- Argon Scripts -->
<!-- Core -->
<script src="/assets/vendor/jquery/dist/jquery.min.js"></script>
<script src="/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Optional JS -->
<script src="/assets/js/bootstrap-datepicker.min.js"></script>
<!-- Argon JS -->
<script src="/assets/js/argon.js?v=1.0.0"></script>
<script src="/assets/js/dropzone.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.3.5/jspdf.plugin.autotable.min.js"></script>
<script src="/assets/js/tableHTMLExport.js" charset="utf-8"></script>
<script src="/assets/js/downloader.js"></script>
<script src="/assets/js/toast.min.js"></script>
<script src="/assets/js/application.js"></script>