<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
    $app = new App();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Offices</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($updated)): ?>
                    <?php if ($updated === true): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> User password updated
                        </div>
                    <?php elseif ($updated === false): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to update User password
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (isset($deleted)): ?>
                    <?php if ($deleted == true): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Success!</strong> User deleted..
                        </div>
                    <?php elseif ($deleted == true): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> User does not exist
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (isset($_GET['edit-user'])): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0">Update Password for - <? echo $_GET['edit-user'] ?></h3>
                        </div>
                        <div class="card-body">
                            <form method='post'>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" name="username" class="form-control" placeholder="Question" value="<? echo $_GET['edit-user'] ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>New Password (Required)</label>
                                            <input type="password" name="password" class="form-control" placeholder="New Password" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label></label>
                                            <input type="submit" name="update" class="btn btn-success">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">All Offices</h3>
                            </div>
                            <div class="col">
                                <ul class="nav justify-content-end">
                                    <a href="#" onclick="exportTableToCSV('office-list.csv')" class="btn btn-primary py-2 px-3" data-toggle="tab">
                                        <span>Export Excel</span>
                                    </a>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush" id='players'>
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Office ID</th>
                                <th scope="col">Office Type</th>
                                <th scope="col">Office Name</th>
                                <th scope="col">Office Address</th>
                                <th scope="col">Contact Person Name</th>
                                <th scope="col">Contact Person Number</th>
                                <th scope="col">Office Parent ID</th>
                                <th scope="col">Is Active</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $app->list_offices(null); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>
