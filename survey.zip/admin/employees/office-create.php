<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
$app = new App();
if (isset($_POST['submit'])){
    $ot = $app->dbHelper->sqlSafePost('office_type');
    $on = $app->dbHelper->sqlSafePost('office_name');
    $oa = $app->dbHelper->sqlSafePost('office_address');
    $cpn = $app->dbHelper->sqlSafePost('contact_name');
    $cpm = $app->dbHelper->sqlSafePost('contact_number');
    
    if (mysqli_query($app->db, "INSERT INTO offices(office_type,office_name,office_address,contact_person_name,contact_person_number) VALUES('$ot','$on','$oa','$cpn','$cpm')")){
        $status = true;
    } else {
        $app->sql_error_log();
        $status = false;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>New Office</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === true): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Added a new Office
                        </div>
                    <?php elseif ($status === false): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to add a new Office
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Add New Office</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method='post' action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Office Type (Required)</label>
                                        <select name="office_type" class="form-control" placeholder="Feeder Code" required>
                                            <option value="Zone">Zone</option>
                                            <option value="Circle">Circle</option>
                                            <option value="Division">Division</option>
                                            <option value="Sub Division">Sub Division</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Office Name (Required)</label>
                                        <input type="text" name="office_name" class="form-control" placeholder="Office Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Office Address</label>
                                        <input type="text" name="office_address" class="form-control" placeholder="Office Address">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Contact Person Name</label>
                                        <input type="text" name="contact_name" class="form-control" placeholder="Contact Person Name">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Contact Person Number</label>
                                        <input type="text" name="contact_number" class="form-control" placeholder="Contact Person Number">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group">
                                        <label></label>
                                        <input type="submit" name="submit" class="btn btn-success">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>