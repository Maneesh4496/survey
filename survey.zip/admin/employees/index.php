<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
$app = new App();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <?php require('inc/templates/header.inc.php'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.css" integrity="sha256-aa0xaJgmK/X74WM224KMQeNQC2xYKwlAt08oZqjeF0E=" crossorigin="anonymous" />
    <style>
        /*th.sorting, th.sorting_asc, th.sorting_desc {
            white-space: normal;
        }
        .table-flush tbody tr:last-child td, .table-flush tbody tr:last-child th {
            white-space: normal;
        }*/
        .card .table td, .card .table th {
            /*padding-left: 0;
            padding-right: 0;*/
            text-align: center;
        }
    </style>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3>Dashboard</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">

                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
</body>
</html>
