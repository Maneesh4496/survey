<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/classes/application.php';
$app = new App();
if (isset($_POST['submit'])){
    $u = $app->dbHelper->sqlSafePost('username');
    $p = md5($app->dbHelper->sqlSafePost("password"));
    $m = $app->dbHelper->sqlSafePost('mrid');
    $z = $app->dbHelper->sqlSafePost('zone');
    $c = $app->dbHelper->sqlSafePost('circle');
    $d = $app->dbHelper->sqlSafePost('division');
    $sd = $app->dbHelper->sqlSafePost('subdivision');
    $sdc = $app->dbHelper->sqlSafePost('subdivisioncode');
    $f = $app->dbHelper->sqlSafePost('feedercode');
    if (mysqli_query($app->db, "INSERT INTO users(username,password,mr_id,zone,circle,division,subdivision,subdivision_code,feeder_code) VALUES('$u','$p','$m','$z','$c','$d','$sd','$sdc','$f')")){
        $status = true;
    } else {
        $app->sql_error_log();
        $status = false;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>New Employee Joining</title>
    <?php require('inc/templates/header.inc.php'); ?>
</head>

<body>
<!-- Sidenav -->
<?php require('inc/templates/sidenav.inc.php'); ?>
<!-- Main content -->
<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <?php if (isset($status)): ?>
                    <?php if ($status === true): ?>
                        <div class="alert alert-success" role="alert">
                            <strong>Success!</strong> Added a new Employee
                        </div>
                    <?php elseif ($status === false): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong>Error!</strong> Failed to add a new Employee
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">New Employee Joining</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method='post' action="">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Select Office</label>
                                        <select name="office" class="form-control" placeholder="Select Office">
                                            <option value="">Select Office</option>
                                            <?php
                                                if ($res = mysqli_query($app->db, "SELECT * FROM offices")) {
                                                    while($row = mysqli_fetch_assoc($res)){
                                                        echo '<option value="'.$row["id"].'" data-type="'.$row["office_type"].'" data-address="'.$row["office_address"].'">'.$row["office_name"].'</option>';
                                                    }
                                                } else {
                                                    echo "SQL Error: ".mysqli_error($app->db);
                                                }

                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Office Type</label>
                                        <input type="disabled" name='office_type' class="form-control" placeholder="Office Type - Auto Fetched" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Office Address</label>
                                        <input type="disabled" name='office_address' class="form-control" placeholder="Office Address - Auto Fetched" disabled>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>QR Code Scanner</label>
                                        <div class="w-100" style="position: relative">
                                            <div class="scanner-overlay">
                                                <svg viewBox="-33 -33 1066.6666 1066.6666" width="1066.6666pt" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="m56.574219 150.324219c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875v-123.046875c0-16.183594 13.113281-29.296875 29.296875-29.296875h123.039062c16.183594 0 29.296875 13.113281 29.296875 29.296875 0 16.179687-13.113281 29.296875-29.296875 29.296875h-93.742187zm404.296875 628.90625c-16.183594 0-29.296875-13.117188-29.296875-29.296875 0-16.183594 13.113281-29.296875 29.296875-29.296875h25.390625c16.179687 0 29.296875 13.113281 29.296875 29.296875 0 16.179687-13.117188 29.296875-29.296875 29.296875zm21.484375-390.625c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875v-25.390625c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875zm179.6875 328.125c-16.183594 0-29.296875-13.117188-29.296875-29.296875 0-16.183594 13.113281-29.296875 29.296875-29.296875h25.390625c16.179687 0 29.296875 13.113281 29.296875 29.296875 0 16.179687-13.117188 29.296875-29.296875 29.296875zm-604.492188-189.453125h136.328125c-.390625 1.894531-.585937 3.851562-.585937 5.859375v87.890625c0 16.179687 13.113281 29.296875 29.296875 29.296875 16.179687 0 29.296875-13.117188 29.296875-29.296875v-87.890625c0-2.007813-.195313-3.964844-.585938-5.859375h258.398438v33.203125h-154.296875c-16.183594 0-29.296875 13.113281-29.296875 29.296875 0 16.179687 13.113281 29.296875 29.296875 29.296875h183.59375c16.179687 0 29.296875-13.117188 29.296875-29.296875v-62.5h109.375v85.9375c0 16.179687 13.113281 29.296875 29.296875 29.296875 16.179687 0 29.296875-13.117188 29.296875-29.296875v-85.9375h202.148437c16.179688 0 29.296875-13.117188 29.296875-29.296875 0-16.183594-13.117187-29.296875-29.296875-29.296875h-133.789062v-56.640625h29.296875c16.179687 0 29.296875-13.117188 29.296875-29.296875 0-16.183594-13.117188-29.296875-29.296875-29.296875h-146.484375c-16.183594 0-29.296875 13.113281-29.296875 29.296875 0 16.179687 13.113281 29.296875 29.296875 29.296875h58.59375v56.640625h-177.734375v-76.171875c0-16.183594-13.117188-29.296875-29.296875-29.296875-16.183594 0-29.296875 13.113281-29.296875 29.296875v76.171875h-452.148438c-16.183593 0-29.296875 13.113281-29.296875 29.296875 0 16.179687 13.113282 29.296875 29.296875 29.296875zm506.835938-359.375c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875v154.296875c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875zm-173.828125 11.71875h66.40625v-11.71875c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875v97.65625c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875v-27.34375h-66.40625v13.671875c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875v-83.984375c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875zm-234.382813 230.46875c-16.175781 0-29.296875-13.117188-29.296875-29.296875 0-16.183594 13.121094-29.296875 29.296875-29.296875h216.804688c16.179687 0 29.296875 13.113281 29.296875 29.296875 0 16.179687-13.117188 29.296875-29.296875 29.296875zm638.679688 388.671875v29.296875c0 16.179687 13.113281 29.296875 29.296875 29.296875 16.179687 0 29.296875-13.117188 29.296875-29.296875v-175.78125c0-16.171875-13.117188-29.296875-29.296875-29.296875-16.183594 0-29.296875 13.125-29.296875 29.296875v87.890625h-97.65625c-16.183594 0-29.296875 13.125-29.296875 29.296875 0 16.179687 13.113281 29.296875 29.296875 29.296875zm-298.828125 58.59375h87.890625c16.179687 0 29.296875-13.117188 29.296875-29.296875v-150.390625c0-16.183594-13.117188-29.296875-29.296875-29.296875-16.183594 0-29.296875 13.113281-29.296875 29.296875v121.09375h-58.59375c-16.183594 0-29.296875 13.113281-29.296875 29.296875 0 16.179687 13.113281 29.296875 29.296875 29.296875zm-162.109375-177.734375c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875v85.9375c0 16.179687-13.117188 29.296875-29.296875 29.296875-16.183594 0-29.296875-13.117188-29.296875-29.296875zm-177.734375-3.90625h123.046875c16.179687 0 29.296875 13.113281 29.296875 29.296875v123.046875c0 16.179687-13.117188 29.296875-29.296875 29.296875h-123.046875c-16.183594 0-29.296875-13.117188-29.296875-29.296875v-123.046875c0-16.183594 13.113281-29.296875 29.296875-29.296875zm93.75 58.59375h-64.453125v64.453125h64.453125zm466.796875-595.703125h123.046875c16.179687 0 29.296875 13.113281 29.296875 29.296875v123.046875c0 16.179687-13.117188 29.296875-29.296875 29.296875h-123.046875c-16.183594 0-29.296875-13.117188-29.296875-29.296875v-123.046875c0-16.183594 13.113281-29.296875 29.296875-29.296875zm93.75 58.59375h-64.453125v64.453125h64.453125zm-654.296875-58.59375c-16.183594 0-29.296875 13.113281-29.296875 29.296875v123.046875c0 16.179687 13.113281 29.296875 29.296875 29.296875h123.046875c16.179687 0 29.296875-13.117188 29.296875-29.296875v-123.046875c0-16.183594-13.117188-29.296875-29.296875-29.296875zm93.75 58.59375v64.453125h-64.453125v-64.453125zm689.453125 648.4375c0-16.183594 13.113281-29.296875 29.296875-29.296875 16.179687 0 29.296875 13.113281 29.296875 29.296875v123.046875c0 16.179687-13.117188 29.296875-29.296875 29.296875h-123.042969c-16.175781 0-29.296875-13.117188-29.296875-29.296875 0-16.183594 13.121094-29.296875 29.296875-29.296875h93.746094zm-941.40625 0v123.046875c0 16.179687 13.113281 29.296875 29.296875 29.296875h123.039062c16.183594 0 29.296875-13.117188 29.296875-29.296875 0-16.183594-13.113281-29.296875-29.296875-29.296875h-93.742187v-93.75c0-16.183594-13.117188-29.296875-29.296875-29.296875-16.183594 0-29.296875 13.113281-29.296875 29.296875zm1000-695.3125v-123.046875c0-16.183594-13.117188-29.296875-29.296875-29.296875h-123.042969c-16.175781 0-29.296875 13.113281-29.296875 29.296875 0 16.179687 13.121094 29.296875 29.296875 29.296875h93.746094v93.75c0 16.179687 13.113281 29.296875 29.296875 29.296875 16.179687 0 29.296875-13.117188 29.296875-29.296875zm0 0" fill-rule="evenodd"/>
                                                </svg>
                                            </div>
                                            <video id="qr-video" class="w-100"></video>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Aadhar QR Code</label>
                                        <input type="text" name="aadhar_qr_code" class="form-control" placeholder="Aadhar QR Code data" disabled>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Employee Name</label>
                                        <input type="text" name='emp_name' class="form-control" placeholder="Employee Name - Auto Fetched">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Employee Gender</label>
                                        <input type="text" name='emp_gender' class="form-control" placeholder="Employee Gender - Auto Fetched">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Father's Name</label>
                                        <input type="text" name='father_name' class="form-control" placeholder="Father's Name - Auto Fetched">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Employee DOB</label>
                                        <input type="text" name='emp_dob' class="form-control" placeholder="Employee DOB - Auto Fetched">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Aadhar Number</label>
                                        <input type="disabled" name='aadhar_number' class="form-control" placeholder="Aadhar ID - Auto Fetched" disabled>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Current Address Line One</label>
                                        <input type="text" name='address_one' class="form-control" placeholder="Address Line One - Auto Fetched">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Current Address Line Two</label>
                                        <input type="text" name='address_two' class="form-control" placeholder="Address Line Two - Auto Fetched">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Is Permanent address is same as Current Address ?</label>
                                        <select type="text" name='perma_selector' class="form-control">
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Permanent Address Line One</label>
                                        <input type="text" name='perma_address_one' class="form-control" placeholder="Address Line One" disabled>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Permanent Address Line Two</label>
                                        <input type="text" name='perma_address_two' class="form-control" placeholder="Address Line Two" disabled>
                                    </div>
                                </div>



                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Job ID</label>
                                        <input type="disabled" name='job_id' class="form-control" placeholder="Job ID - Auto Fetched" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Discom Login ID</label>
                                        <input type="disabled" name='discom_login_id' class="form-control" placeholder="Discom login ID">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group">
                                        <label></label>
                                        <input type="submit" name="submit" class="btn btn-success">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php require('inc/templates/footer.inc.php'); ?>
    </div>
</div>
<?php require('inc/templates/scripts.inc.php'); ?>
<script>
    $('select[name="office"]').change(function(e) {
        $('input[name="office_type"]').val($('select[name="office"] option:selected').data('type'));
        $('input[name="office_address"]').val($('select[name="office"] option:selected').data('address'));
    });
    $('select[name="perma_selector"]').change(function (e) {
        console.log($('select[name="perma_selector"]').val());
        $('input[name="perma_address_one"]').val($('input[name="address_one"]').val());
        $('input[name="perma_address_two"]').val($('input[name="address_two"]').val());
        if ($('select[name="perma_selector"]').val() == 'no'){
            $('input[name="perma_address_one"]').attr('disabled', false);
            $('input[name="perma_address_two"]').attr('disabled', false);
        } else {
            $('input[name="perma_address_one"]').attr('disabled', true);
            $('input[name="perma_address_two"]').attr('disabled', true);
        }
    });
</script>
<script type="module">
    import QrScanner from "/assets/js/qr-scanner.min.js";
    QrScanner.WORKER_PATH = '/assets/js/qr-scanner-worker.min.js';

    const video = document.getElementById('qr-video');
    const camQrResult = document.getElementById('cam-qr-result');
    const camQrResultTimestamp = document.getElementById('cam-qr-result-timestamp');

    // ####### Web Cam Scanning #######

    QrScanner.hasCamera().then(hasCamera => console.log(hasCamera));

    const scanner = new QrScanner(video, result => qrRecieved(result));
    scanner.start();

    function qrRecieved(xml){
        console.log(xml);
        if ($('input[name="aadhar_qr_code"]').val() == "") {
            iqwerty.toast.Toast("QR Code Fetched");
            $('input[name="aadhar_qr_code"]').val(xml);
        } else {
            if (getXMLValue(xml, "uid") != getXMLValue($('input[name="aadhar_qr_code"]').val(), "uid")) {
                iqwerty.toast.Toast("QR Code Fetched");
                $('input[name="aadhar_qr_code"]').val(xml);
            }
        }
        // BIND
        $('input[name="emp_name"]').val(getXMLValue(xml, "name"));
        $('input[name="emp_gender"]').val(getXMLValue(xml, "gender"));
        $('input[name="emp_dob"]').val(getXMLValue(xml, "gender"));
        $('input[name="father_name"]').val(getXMLValue(xml, "gname"));
        $('input[name="aadhar_number]').val(getXMLValue(xml, "uid"));
        $('input[name="address_one"]').val(getXMLValue(xml, "house")+ ", "+getXMLValue(xml, "street")+", "+getXMLValue(xml, 'lm'));
        $('input[name="address_two"]').val(getXMLValue(xml, "dist")+", "+getXMLValue(xml,"state"))
    }
    function getXMLValue(xml, selector){
        var data = xml.split(selector+"=");
        var string = data[1].split('" ');
        return string[0].replace(/['"]+/g, '');
    }
</script>
</body>
</html>